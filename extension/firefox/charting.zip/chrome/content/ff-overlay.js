charting.onFirefoxLoad = function(event) {
  document.getElementById("contentAreaContextMenu")
          .addEventListener("popupshowing", function (e){ charting.showFirefoxContextMenu(e); }, false);
};

charting.showFirefoxContextMenu = function(event) {
  // show or hide the menuitem based on what the context menu is on
  document.getElementById("context-charting").hidden = gContextMenu.onImage;
};

window.addEventListener("load", charting.onFirefoxLoad, false);
