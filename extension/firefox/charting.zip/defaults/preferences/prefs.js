pref("extensions.charting.boolpref", false);
pref("extensions.charting.intpref", 0);
pref("extensions.charting.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.charting@mhnltd.co.uk.description", "chrome://charting/locale/overlay.properties");
